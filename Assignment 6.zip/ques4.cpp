#include<iostream>
using namespace std;

class B;  // Forward declaration

class A {
    int x;
public:
    A(int a) {
        x = a;
    }

    // Declare friend function
    friend int add(A, B);
};

class B {
    int y;
public:
    B(int b) {
        y = b;
    }

    // Declare friend function
    friend int add(A, B);
};

// Friend function definition
int add(A obj1, B obj2) {
    return obj1.x + obj2.y;
}

int main() {
    A obj1(10);
    B obj2(20);

    int result = add(obj1, obj2);

    cout << "Sum = " << result;

    return 0;
}