#include<iostream>
using namespace std;

#define MAX 100


class Book {
public:
    string title, author, ISBN;

    // Default Constructor
    Book() {
        this->title = "";
        this->author = "";
        this->ISBN = "";
    }

    // Parameterized Constructor
    Book(string title, string author, string ISBN) {
        this->title = title;
        this->author = author;
        this->ISBN = ISBN;
    }

    // Copy Constructor
    Book(const Book &b) {
        this->title = b.title;
        this->author = b.author;
        this->ISBN = b.ISBN;
    }
};

class Library {
    Book books[MAX];
    int count;

public:
    Library() {
        this->count = 0;
    }

    // Add Book using constructor
    bool addNewBook(string &title, string &author, string &ISBN) {
        if (count >= MAX)
            return false;

        books[count] = Book(title, author, ISBN);
        count++;
        return true;
    }

    // Remove Book
    bool removeBooks(string &ISBN) {
        for (int i = 0; i < count; i++) {
            if (books[i].ISBN == ISBN) {
                for (int j = i; j < count - 1; j++) {
                    books[j] = books[j + 1];
                }
                count--;
                return true;
            }
        }
        return false;
    }

    // Display
    void displayDetails() {
        if (count == 0) {
            cout << "No books"<<endl;
            return;
        }

        for (int i = 0; i < count; i++) {
            cout << "\nBook " << i+1 << endl;
            cout << "Title: " << books[i].title << endl;
            cout << "Author: " << books[i].author << endl;
            cout << "ISBN: " << books[i].ISBN << endl;
        }
    }
};

int main() {
    Library lib;

    // Initializer List Style
    Book b1("C++", "Bjarne", "101");
    Book b2("DSA", "Mark", "102");

    string t, a, i;

    t="OS"; a="Galvin"; i="103";
    lib.addNewBook(t,a,i);

    t="DBMS"; a="Korth"; i="104";
    lib.addNewBook(t,a,i);

    t="CN"; a="Tanenbaum"; i="105";
    lib.addNewBook(t,a,i);

    // Add using copy constructor
    lib.addNewBook(b1.title, b1.author, b1.ISBN);
    lib.addNewBook(b2.title, b2.author, b2.ISBN);

    cout << "\n Before Removal "<<endl;
    lib.displayDetails();

    // Remove book
    string rem = "103";
    if (lib.removeBooks(rem))
        cout << "\nBook removed successfully"<<endl;
    else
        cout << "\nBook not found"<<endl;

    cout << "\n After Removal"<<endl;
    lib.displayDetails();

    return 0;
}