#include<iostream>
using namespace std;

class Complex {
    float real, imag;

public:
    // Parameterized Constructor
    Complex(float r, float i) {
        real = r;
        imag = i;
    }

    // Copy Constructor
    Complex(const Complex &c) {
        real = c.real;
        imag = c.imag;
    }

    // Display Function
    void display() {
        cout << real << " + " << imag << "i" << endl;
    }

    // Friend Function Declaration
    friend void sum(Complex, Complex);
};

// Friend Function Definition
void sum(Complex c1, Complex c2) {
    float r = c1.real + c2.real;
    float i = c1.imag + c2.imag;

    cout << "Sum = " << r << " + " << i << "i" << endl;
}

int main() {
    Complex c1(2, 3);
    Complex c2(4, 5);

    // Copy constructor
    Complex c3 = c1;

    cout << "Complex Number 1: ";
    c1.display();

    cout << "Complex Number 2: ";
    c2.display();

    cout << "Copied Complex Number: ";
    c3.display();

    // Sum using friend function
    sum(c1, c2);

    return 0;
}