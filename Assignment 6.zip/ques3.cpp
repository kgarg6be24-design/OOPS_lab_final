#include<iostream>
#include<string>
using namespace std;

class Account {
    const long accountNumber;
    long transactionID;
    string transactionType;
    double balance;

    static long nextTransactionID;

public:
    // Constructor
    Account(long accNo, double bal) : accountNumber(accNo) {
        balance = bal;
        transactionID = 0;
        transactionType = "None";
    }

    // Deposit (credit)
    long depositAmount(const long to, const long from, const double amount) {
        if (accountNumber == to) {
            balance += amount;
            transactionType = "Credit";
            transactionID = ++nextTransactionID;
        }
        return transactionID;
    }

    // Withdraw (debit)
    long creditAmount(const long to, const long from, const double amount) {
        if (accountNumber == from && balance >= amount) {
            balance -= amount;
            transactionType = "Debit";
            transactionID = ++nextTransactionID;
        }
        return transactionID;
    }

    // Display (const function)
    void displayDetails() const {
        cout << "\nAccount No: " << accountNumber << endl;
        cout << "Balance: " << balance << endl;
        cout << "Last Transaction ID: " << transactionID << endl;
        cout << "Transaction Type: " << transactionType << endl;
    }
};

// Static member initialization
long Account::nextTransactionID = 1000;

int main() {
    Account acc[5] = {
        Account(101, 5000),
        Account(102, 6000),
        Account(103, 7000),
        Account(104, 8000),
        Account(105, 9000)
    };

    // Perform transactions
    acc[0].depositAmount(101, 102, 1000);   // credit
    acc[1].creditAmount(101, 102, 500);     // debit

    acc[2].depositAmount(103, 104, 2000);
    acc[3].creditAmount(103, 104, 1000);

    acc[4].depositAmount(105, 101, 1500);

    // Display all accounts
    cout <<"\n Account Details "<<endl;
    for (int i = 0; i < 5; i++) {
        acc[i].displayDetails();
    }

    return 0;
}