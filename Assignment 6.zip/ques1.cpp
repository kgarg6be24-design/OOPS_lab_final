#include<iostream>
using namespace std;


class Book {
public:
    string title;
    string author;
    string ISBN;
};

class Library {
    Book books[100];
    int count;

public:
    Library() {
        count = 0;
    }

    // a) Add Book
    bool addNewBook(string &title, string &author, string &ISBN) {
        if (count >= 100)
            return false;

        books[count].title = title;
        books[count].author = author;
        books[count].ISBN = ISBN;
        count++;
        return true;
    }

    // b) Remove Book
    bool removeBooks(string &ISBN);

    // c) Display
    void displayDetails() {
        if (count == 0) {
            cout << "No books available"<<endl;
            return;
        }

        for (int i = 0; i < count; i++) {
            cout << "\nBook " << i+1 << endl;
            cout << "Title: " << books[i].title << endl;
            cout << "Author: " << books[i].author << endl;
            cout << "ISBN: " << books[i].ISBN << endl;
        }
    }
};

// b) Remove Book 
bool Library::removeBooks(string &ISBN) {
    for (int i = 0; i < count; i++) {
        if (books[i].ISBN == ISBN) {
            for (int j = i; j < count - 1; j++) {
                books[j] = books[j + 1];
            }
            count--;
            return true;
        }
    }
    return false;
}

int main() {
    Library lib;

    // Adding 5 books
    string t, a, i;

    t="C++"; a="R.D sharma"; i="101";
    lib.addNewBook(t,a,i);

    t="DSA"; a="RS Aggarwal"; i="102";
    lib.addNewBook(t,a,i);

    t="OS"; a="Footprint without feet"; i="103";
    lib.addNewBook(t,a,i);

    t="DBMS"; a="Korth"; i="104";
    lib.addNewBook(t,a,i);

    t="CN"; a="Tanenbaum"; i="105";
    lib.addNewBook(t,a,i);

    cout << "\nBooks Before Removal "<<endl;
    lib.displayDetails();

    // Remove 1 book
    string rem = "103";
    if (lib.removeBooks(rem))
        cout << "\nBook removed successfully"<<endl;
    else
        cout << "\nBook not found\n";

    cout << "\nBooks After Removal"<<endl;
    lib.displayDetails();

    return 0;
}