#include<iostream>
using namespace std;

class Array {
    int a[5];

public:

    void input() {
        cout << "Enter 5 elements:" << endl;
        for(int i = 0; i < 5; i++) {
            cin >> a[i];
        }
    }

    int& operator [] (int index) {
        if(index < 0 || index >= 5) {
            cout << "Error: Index out of bounds!" << endl;
            exit(0); 
        }
        return a[index];
    }
};

int main() {
    Array obj;
    obj.input();

    int index;
    cout << "Enter index to access: " << endl;
    cin >> index;

    cout << "Element = " << obj[index] << endl;

    return 0;
}