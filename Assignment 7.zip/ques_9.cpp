#include<iostream>
using namespace std;

class Numbers {
public:
   

    void operator() (int a) {
        cout << "One value: " << a << endl;
    }

    void operator() (int a, int b) {
        cout << "Two values: " << a << " " << b << endl;
    }

    void operator() (int a, int b, int c) {
        cout << "Three values: " << a << " " << b << " " << c << endl;
    }
};

int main() {
    Numbers obj;

    obj(10); 
    obj(10, 20);    
    obj(10, 20, 30);   

    return 0;
}