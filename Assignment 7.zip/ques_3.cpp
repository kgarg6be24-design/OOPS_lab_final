#include<iostream>
#include<cmath>
using namespace std;

// Right angle triangle
float area(float base, float height) {
    return 0.5 * base * height;
}

// Equilateral triangle
float area(float side) {
    return (sqrt(3)/4) * side * side;
}

// Isosceles triangle
float area(float equalSide, float base, int flag) {
    float h = sqrt(equalSide*equalSide - (base*base)/4);
    return 0.5 * base * h;
}

int main() {
    float b, h, s, eSide;

    
    cout << "Enter base and height of right triangle: ";
    cin >> b >> h;
    cout << "Area (Right Triangle) = " << area(b, h) << endl;


    cout << "\nEnter side of equilateral triangle: ";
    cin >> s;
    cout << "Area (Equilateral Triangle) = " << area(s) << endl;


    cout << "\nEnter equal side and base of isosceles triangle: ";
    cin >> eSide >> b;
    cout << "Area (Isosceles Triangle) = " << area(eSide, b, 1) << endl;

    return 0;
}