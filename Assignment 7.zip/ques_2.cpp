#include<iostream>
using namespace std;


class Shape {
public:
    // Virtual functions
    virtual void area() {
        cout << "Area not defined"<<endl;
    }

    virtual void display() {
        cout << "This is a shape"<<endl;
    }
};


class Circle : public Shape {
    float r;
public:
    Circle(float r) {
        this->r = r;
    }

    void area() {
        cout << "Area of Circle = " << 3.14 * r * r << endl;
    }

    void display() {
        cout << "Shape: Circle"<<endl;
    }
};


class Rectangle : public Shape {
    float l, b;
public:
    Rectangle(float l, float b) {
        this->l = l;
        this->b = b;
    }

    void area() {
        cout << "Area of Rectangle = " << l * b << endl;
    }

    void display() {
        cout << "Shape: Rectangle"<<endl;
    }
};

class Triangle : public Shape {
    float b, h;
public:
    Triangle(float b, float h) {
        this->b = b;
        this->h = h;
    }

    void area() {
        cout << "Area of Triangle = " << (b * h) / 2 << endl;
    }

    void display() {
        cout << "Shape: Triangle"<<endl;
    }
};

int main() {
    int x,y,z,u,v;// x is radius, y = width, z = height
    cout<<"Enter radius , width , height "<<endl;
    cin>>x>>y>>z>>u>>v;
    Shape *s;  

    Circle c(x);
    Rectangle r(y,z);
    Triangle t(u, v);

    // Circle
    s = &c;
    s->display();
    s->area();

    // Rectangle
    s = &r;
    s->display();
    s->area();

    // Triangle
    s = &t;
    s->display();
    s->area();

    return 0;
}