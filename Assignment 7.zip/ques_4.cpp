#include<iostream>
using namespace std;

class Student {
protected:
    string name;

public:
    void setName(string n) {
        name = n;
    }

    // Pure virtual function
    virtual void display() = 0;
};


class Engineering : public Student {
public:
    void display() {
        cout << "Engineering Student: " << name << endl;
    }
};


class Medicine : public Student {
public:
    void display() {
        cout << "Medicine Student: " << name << endl;
    }
};


class Science : public Student {
public:
    void display() {
        cout << "Science Student: " << name << endl;
    }
};

int main() {
    Student* s[3];

    Engineering e;
    Medicine m;
    Science sc;

  
    s[0] = &e;
    s[1] = &m;
    s[2] = &sc;


    s[0]->setName("Krish");
    s[1]->setName("Shivam");
    s[2]->setName("Koushik");


    for (int i = 0; i < 3; i++) {
        s[i]->display();
    }

    return 0;
}