#include <iostream>
using namespace std;

class B;

class A {
    int x;
public:
    void set(int a) {
        x = a;
    }
    void show() {
        cout << "A = " << x << endl;
    }
    friend void swap(A &, B &);
};

class B {
    int y;
public:
    void set(int b) {
        y = b;
    }
    void show() {
        cout << "B = " << y << endl;
    }
    friend void swap(A &, B &);
};

void swap(A &obj1, B &obj2) {
    int temp;
    temp = obj1.x;
    obj1.x = obj2.y;
    obj2.y = temp;
}

int main() {
    A obj1;
    B obj2;

    obj1.set(10);
    obj2.set(20);

    cout << "Before swapping" << endl;
    obj1.show();
    obj2.show();

    swap(obj1, obj2);

    cout << "After swapping" << endl;
    obj1.show();
    obj2.show();

    return 0;
}
