#include <iostream>
using namespace std;

class Rectangle {
    float length, breadth;

public:
    void set(float l, float b) {
        length = l;
        breadth = b;
    }

    float area() {
        return length * breadth;
    }
};

int main() {
    int n;
    cout << "Enter number of rectangles: ";
    cin >> n;

    Rectangle r[n];

    for(int i = 0; i < n; i++) {
        float l, b;
        cout << "Enter length and breadth of rectangle " << i + 1 << ": ";
        cin >> l >> b;
        r[i].set(l, b);
    }

    cout << endl << "Areas of rectangles:" << endl;
    for(int i = 0; i < n; i++) {
        cout << "Rectangle " << i + 1 << " Area = " << r[i].area() << endl;
    }

    return 0;
}
