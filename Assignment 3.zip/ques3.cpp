#include <iostream>
using namespace std;

class B;

class A {
    int x;
public:
    void set(int a) {
        x = a;
    }
    friend int add(A, B);
};

class B {
    int y;
public:
    void set(int b) {
        y = b;
    }
    friend int add(A, B);
};

int add(A obj1, B obj2) {
    return obj1.x + obj2.y;
}

int main() {
    A obj1;
    B obj2;
    int sum;

    obj1.set(15);
    obj2.set(25);

    sum = add(obj1, obj2);

    cout << "Sum = " << sum;

    return 0;
}
