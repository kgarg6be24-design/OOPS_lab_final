#include <iostream>
using namespace std;

class Number {
public:
    int x;

    void set(int a) {
        x = a;
    }

    void show() {
        cout << "Value = " << x << endl;
    }
};

Number addTen(Number &obj) {
    obj.x = obj.x + 10;
    return obj;
}

int main() {
    Number n1, n2;

    n1.set(20);
    n2 = addTen(n1);

    cout << "Original Object after function call:" << endl;
    n1.show();

    cout << "Returned Object:" << endl;
    n2.show();

    return 0;
}
