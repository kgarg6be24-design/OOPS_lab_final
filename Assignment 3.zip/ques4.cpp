#include <iostream>
using namespace std;

class B;

class A {
    int x;
public:
    void set(int a) {
        x = a;
    }
    friend class B;
};

class B {
public:
    void show(A obj) {
        cout << "Value = " << obj.x;
    }
};

int main() {
    A obj;
    B obj2;

    obj.set(50);
    obj2.show(obj);

    return 0;
}
