#include<iostream>
#include<fstream>
using namespace std;

int main() {
    ofstream fout("data.txt");
    fout << "This is a sample file with multiple lines.\nSecond line here.";
    fout.close();

    ifstream fin("data.txt");

    // i) Move to 10th byte
    fin.seekg(9);

    // ii) Display position
    cout << "Current position: " << fin.tellg() << endl;

    // iii) Read remaining content
    char ch;
    while(fin.get(ch)) {
        cout << ch;
    }

    fin.close();
}