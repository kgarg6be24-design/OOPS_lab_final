#include<iostream>
#include<fstream>
using namespace std;

class Student {
    int roll;
    char name[20];
    float marks;

public:
    void input() {
        cout << "Enter roll, name, marks: ";
        cin >> roll >> name >> marks;
    }

    void display() {
        cout << "Roll: " << roll 
             << " Name: " << name 
             << " Marks: " << marks << endl;
    }
};

int main() {
    Student s;


    ofstream fout("student.dat", ios::binary);
    s.input();
    fout.write((char*)&s, sizeof(s));
    fout.close();

    ifstream fin("student.dat", ios::binary);
    fin.read((char*)&s, sizeof(s));
    fin.close();

    cout << "\nData read from file:\n";
    s.display();

    return 0;
}