#include<iostream>
#include<fstream>
using namespace std;

int main() {
    int n;
    cin>>n;
    ofstream fout("file.txt");
    for(char ch = 'A'; ch <= 'Z'; ch++) {
        fout << ch;
    }
    fout.close();

    ifstream fin("file.txt");
    fin.seekg(n);

    char ch;
    fin.get(ch);
    cout <<n<< "th character: " << ch;

    fin.close();
}