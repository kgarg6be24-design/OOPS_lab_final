#include<iostream>
#include<fstream>
using namespace std;

int main() {
    ofstream fout("hello.txt");

    string str = "HelloWorld";

    // i & ii: write and show position
    for(int i = 0; i < str.length(); i++) {
        fout.put(str[i]);
        cout << "Position: " << fout.tellp() << endl;
    }

    fout.close();

    // iii: replace "World" with "C++"
    fstream file("hello.txt", ios::in | ios::out);

    file.seekp(5);
    file << "C++";

    file.close();

    cout << "Replacement done";
}