#include<iostream>
#include<fstream>
using namespace std;


void countAlphabets() {
    ifstream fin;
    fin.open("NOTES.TXT");

    if(!fin) {
        cout << "Error opening file!";
        return;
    }

    char ch;
    int count = 0;

    while(fin.get(ch)) {
        if((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z')) {
            count++;
        }
    }

    fin.close();

    cout << "Number of alphabets: " << count << endl;
}

int main() {
    countAlphabets();
    return 0;
}