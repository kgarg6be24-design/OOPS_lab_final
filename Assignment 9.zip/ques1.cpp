#include<iostream>
#include<fstream>
using namespace std;

int main()
{

    ofstream fout("NUM.TXT");
    for(int i=1; i<=200; i++)
    {
        fout << i << " ";
    }
    fout.close();

    ifstream fin("NUM.TXT");
    ofstream f1("ODD.TXT");
    ofstream f2("EVEN.TXT");

    int num;

    while(fin >> num)
    {
        if(num % 2 == 0)
            f2 << num << " ";
        else
            f1 << num << " ";
    }

    fin.close();
    f1.close();
    f2.close();

    int choice;
    cout<<"Enter choice: ";
    cin>>choice;

    ifstream show;

    switch(choice)
    {
        case 1:
            show.open("ODD.TXT");
            cout<<"Odd numbers: ";
            break;

        case 2:
            show.open("EVEN.TXT");
            cout<<"Even numbers: ";
            break;

        default:
            cout<<"Invalid choice";
            return 0;
    }

    while(show >> num)
    {
        cout << num << " ";
    }

    show.close();

    return 0;
}