#include<iostream>
#include<fstream>
using namespace std;

int main() {
    ifstream fin;
    ofstream fout;

    fin.open("source.txt");
    fout.open("destination.txt");

    if(!fin || !fout) {
        cout << "Error opening file!";
        return 1;
    }

    char ch;

    while(fin.get(ch)) {
        fout.put(ch);
    }

    fin.close();
    fout.close();

    cout << "File copied successfully!";
    return 0;
}