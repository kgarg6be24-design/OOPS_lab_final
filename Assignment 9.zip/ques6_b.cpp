#include<iostream>
#include<fstream>
using namespace std;

int main() {
    int n;
    cin>>n;
    fstream file("file.txt", ios::in | ios::out);

    file.seekp(n-1);
    file.put('X');

    file.close();
    cout <<n<< "th character overwritten";
}