#include <iostream>
using namespace std;

template <class T>
void swapValues(T &a, T &b) {
    T temp;
    temp = a;
    a = b;
    b = temp;
}

int main() {
    int x, y;
    cout << "Enter the value of x and y ";
    cin >> x >> y;

    swapValues(x, y); 

    float a, b;
    cout << "Enter the value of a and b ";
    cin >> a >> b;

    swapValues(a, b);

    // after swapping
    cout << "values of x = " << x << " and y = " << y << endl;
    cout << "values of a = " << a << " and b = " << b << endl;

    return 0;
}