#include<iostream>
using namespace std;

template<class T>
void minimum(T arr[], int n) {
    T x = arr[0];
    for(int i=1;i<n;i++){
        if(arr[i]<x) {
            x = arr[i];
        }
    }
    cout<<"minimum is "<<x<<endl;
}

int main() {
    int n;
    cout<<"number of elements ";
    cin>>n;

    int arr[n];
    for(int i=0;i<n;i++) {
        cin>>arr[i];
    }

    minimum(arr,n);
    return 0;
}