#include<iostream>
using namespace std;

int linearsearch(int arr[],int size,int target) {
    for(int i=0;i<size;i++) {
        if(arr[i]==target) {
            cout<<" "<<target<<" is present "<<endl;
            return i;
        }
    }
    return -1;
}

int main() {
    int size , target;
    cout<<"Enter array's size and target ";
    cin>>size>>target;

    int arr[size];
    for(int i = 0;i<size;i++) {
        cin>>arr[i];
    } 
    cout<<"Target index is "<<linearsearch(arr,size,target);

    
    return 0;
}