#include<iostream>
using namespace std;

// i) Single parameter
template<class T>
void process(T x) {
    cout << "Single parameter: " << x << endl;
}

// ii) Two parameters of same type
template<class T>
void process(T x, T y) {
    cout << "Two parameters (same type): " << x << " , " << y << endl;
}

// iii) Two parameters of different types
template<class T, class U>
void process(T x, U y) {
    cout << "Two parameters (different types): " << x << " , " << y << endl;
}

int main() {
    int a,b;
    float c;
    cout<<"Enter a , b and c ";
    cin>>a>>b>>c;
    process(a);              // single parameter
    process(a, b);          // same type
    process(a,c);        // different types

    return 0;
}