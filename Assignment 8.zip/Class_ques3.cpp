#include<iostream>
using namespace std;

template<class T>
class Pair {
    T a, b;

public:
    void setData(T x, T y) {
        a = x;
        b = y;
    }

    void display() {
        cout << "Values: " << a << " , " << b << endl;
    }
};

int main() {
    Pair<int> p;
    p.setData(10, 20);
    p.display();
}