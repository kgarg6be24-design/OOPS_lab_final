#include<iostream>
using namespace std;

template<class T>
class Queue {
    T arr[100];
    int front, rear;

public:
    Queue() {
        front = rear = -1;
    }

    void enqueue(T x) {
        if(rear == 99) {
            cout << "Queue Overflow\n";
            return;
        }
        if(front == -1) front = 0;
        arr[++rear] = x;
    }

    void dequeue() {
        if(front == -1 || front > rear) {
            cout << "Queue Underflow\n";
            return;
        }
        cout << "Dequeued: " << arr[front++] << endl;
    }
};

int main() {
    Queue<int> q;
    q.enqueue(5);
    q.enqueue(10);
    q.dequeue();
}