#include<iostream>
using namespace std;

template<class T>
class Arithmetic {
    T a, b;

public:
    void setData(T x, T y) {
        a = x;
        b = y;
    }

    void operations() {
        cout << "Addition: " << a + b << endl;
        cout << "Subtraction: " << a - b << endl;
        cout << "Multiplication: " << a * b << endl;
        cout << "Division: " << a / b << endl;
    }
};

int main() {
    Arithmetic<int> obj;
    obj.setData(10, 5);
    obj.operations();
}